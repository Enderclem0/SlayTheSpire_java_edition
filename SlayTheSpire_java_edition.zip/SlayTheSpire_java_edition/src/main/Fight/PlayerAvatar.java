package main.Fight;

public class PlayerAvatar {
}
