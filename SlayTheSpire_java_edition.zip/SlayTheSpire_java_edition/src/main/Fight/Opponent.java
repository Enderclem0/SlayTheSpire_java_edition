package main.Fight;

public class Opponent {
}
