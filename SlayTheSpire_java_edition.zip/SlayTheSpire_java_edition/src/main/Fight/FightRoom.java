package main.Fight;

public class FightRoom {
}
