package main.Card;

public class Discard {
}
