package main.Card;

public class Card {
    private int EnergyCost;
    private String name;

    public Card(int energyCost, String name, String type) {
        EnergyCost = energyCost;
        this.name = name;
    }
}
