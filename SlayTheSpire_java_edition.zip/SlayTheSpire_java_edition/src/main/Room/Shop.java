package main.Room;

public class Shop {
}
