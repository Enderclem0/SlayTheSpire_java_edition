package main;

public class Player {
}
