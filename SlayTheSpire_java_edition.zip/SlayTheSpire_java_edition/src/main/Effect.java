package main;

public enum Effect {
}
